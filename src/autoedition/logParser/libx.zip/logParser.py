import pickle
import pprint
from time import sleep
from twisted.internet import reactor
from twisted.web.client import getPage

# Convert an IP string into a decimal number.
def convertIP(ip):
	ipSplit = ip.partition(".")
	decimalIP = int(ipSplit[0]) * 256 * 256 * 256
	ipSplit = ipSplit[2].partition(".")
	decimalIP += int(ipSplit[0]) * 256 * 256
	ipSplit = ipSplit[2].partition(".")
	decimalIP += int(ipSplit[0]) * 256
	decimalIP += int(ipSplit[2])
	return decimalIP

# Holds the binary tree of CIDR groups.
class ipTree():
	def __init__(self):
		self.root = {}
		self.numIPs = 0
	
	# Adds an IP to the tree. Parameters are the decimal IP to be added and the CIDR value.
	def addIP(self, ip, cidr):
		currentNode = self.root
		bit = 31
		currentBitValue = (ip >> bit) % 2
		while 1:
			try:
				currentNode = currentNode[currentBitValue]
			except KeyError:
				currentNode[currentBitValue] = {}
				currentNode = currentNode[currentBitValue]
			
			bit -= 1
			if bit < (32 - cidr):
				if "ip" not in currentNode:
					currentNode["ip"] = ip
					self.numIPs += 1
				return
			currentBitValue = (ip >> bit) % 2
	
	# Takes a decimal IP and returns True or False depending on if the IP is in the tree.
	def inTree(self, ip):
		currentNode = self.root
		bit = 31
		currentBitValue = (ip >> bit) % 2
		while 1:
			try:
				currentNode = currentNode[currentBitValue]
			except KeyError:
				return False
			
			bit -= 1
			if "ip" in currentNode:
				return True
			if bit < 0:
				return False
			currentBitValue = (ip >> bit) % 2
	
	# Use pretty print to dump the tree.
	def printTree(self):
		pp = pprint.PrettyPrinter(indent=0)
		pp.pprint(self.root)

# A single request to ARIN's WHOIS server.
class singleRequest():
	def __init__(self, ip, requestId, processor):
		self.requestId = requestId
		self.processor = processor
		self.decimalIP = convertIP(ip)
		urlToGet = "http://whois.arin.net/rest/ip/" + ip + ".txt"
		print(urlToGet)
		self.request = getPage(urlToGet)
		self.request.addCallback(self.finishRequest)
	
	def finishRequest(self, output):
		self.processor.finishedRequests.append([self.requestId, output, self.decimalIP])
		self.processor.refresh()

# IPs to query against WHOIS are added to the self.ips variable. When start() is called, the Twisted Reactor starts and processes the IPs in parallel.
class ipProcessor():
	def __init__(self, numRequests, tree, delay):
		self.numRequests = numRequests
		self.tree = tree
		self.delay = delay
		self.requests = []
		for i in range(numRequests):
			self.requests.append(None)
		self.requestsInUse = []
		for i in range(numRequests):
			self.requestsInUse.append(False)
		self.numRequestsIdle = numRequests
		self.ips = []
		self.finishedRequests = []
	
	# Begin processing the IPs. If the number of IPs is less than the number of parallel requests, we knock down the number of parallel requests to accomodate that.
	def start(self):
		if len(self.ips) < self.numRequests:
			self.numRequests = len(self.ips)
			self.numRequestsIdle = self.numRequests
		if self.numRequests is 0:
			return
		for i in range(self.numRequests):
			self.requests[i] = singleRequest(self.ips[0], i, self)
			self.ips = self.ips[1:]
			self.requestsInUse[i] = True
			self.numRequestsIdle -= 1
		reactor.run()
	
	# Called every time a callback function runs. Processes finished requests and adds new ones to the system.
	def refresh(self):
		while len(self.finishedRequests) > 0:
			finishedRequest = self.finishedRequests[0][0]
			requestOutput = self.finishedRequests[0][1]
			decimalIP = self.finishedRequests[0][2]
			self.finishedRequests = self.finishedRequests[1:]
			self.requestsInUse[finishedRequest] = False
			self.numRequestsIdle += 1
			
			# We need to figure out the CIDR group to use, not an easy task. Some queries return multiple groups, and not all cover the called IP. We find the CIDR group that covers the called IP and that covers the most IPs in total.
			secondLine = requestOutput.partition("\n")[2].partition("\n")[0]
			cidrLine = secondLine[16:]
			cidrIP = ""
			cidrValue = 64
			cidrPartition = ['', '', cidrLine]
			while cidrPartition[2] is not "":
				cidrPartition = cidrPartition[2].partition("/")
				newIP = cidrPartition[0]
				cidrPartition = cidrPartition[2].partition(", ")
				newValue = int(cidrPartition[0])
				newStart = convertIP(newIP)
				newEnd = newStart + 2 ** (32 - newValue)
				if newValue < cidrValue and decimalIP > newStart and decimalIP < newEnd:
					cidrIP = newIP
					cidrValue = newValue
			print(cidrIP + "/" + str(cidrValue))
			self.tree.addIP(convertIP(cidrIP), cidrValue)
		
		# Now we process new requests.
		while self.numRequestsIdle > 0 and len(self.ips) > 0:
			for i in range(self.numRequests):
				if self.requestsInUse[i] is False:
					self.requests[i] = singleRequest(self.ips[0], i, self)
					self.ips = self.ips[1:]
					self.requestsInUse[i] = True
					self.numRequestsIdle -= 1
					break
		
		# If we are out of requests, we stop the reactor and clean up. The main function will then resume.
		if self.numRequestsIdle is self.numRequests and len(self.ips) is 0:
			reactor.stop()
			return
		
		# Delay the program to prevent hitting ARIN servers too hard.
		sleep(self.delay)

# Open the tree file from tree.bin, and failing that, create a new one.
try:
	tree = pickle.load(open("tree.bin", "rb"))
	print("Opening tree with " + str(tree.numIPs) + " IP addresses stored.")
except IOError:
	tree = ipTree()
	print("Creating new tree.")

# Initialize the tools we will use.
processor = ipProcessor(4, tree, 1)
logFile = open("editioniplog.txt")

# Iterate over the lines of the log file. If an IP isn't in the tree, we add it to the processor.
currentLine = logFile.readline()
while currentLine is not "":
	currentLineIPs = currentLine[currentLine.index(" ") + 1:]
	currentLineSplit = currentLineIPs.partition(" ")
	firstIP = currentLineSplit[0]
	while "\n" not in firstIP:
		if tree.inTree(convertIP(firstIP)) is False:
			processor.ips.append(firstIP)
		currentLineSplit = currentLineSplit[2].partition(" ")
		firstIP = currentLineSplit[0]
	if tree.inTree(convertIP(firstIP)) is False:
		processor.ips.append(firstIP[:-1])
	
	currentLine = logFile.readline()

# Process the IPs.
processor.start()

# Save the tree back to the file.
pickle.dump(tree, open("tree.bin", "wb"))
print("Saving tree with " + str(tree.numIPs) + " IP addresses stored.")